banner = input("""
\033[1;31m
   _____ _               _          _____             _    
  / ____| |             | |        |  __ \           | |   
 | |  __| |__   ___  ___| |_ ______| |  | | __ _ _ __| | __
 | | |_ | '_ \ / _ \/ __| __|______| |  | |/ _` | '__| |/ /
 | |__| | | | | (_) \__ \ |_       | |__| | (_| | |  |   < 
  \_____|_| |_|\___/|___/\__|      |_____/ \__,_|_|  |_|\_\\
                       \033[1;32m  https://github.com/abduazizdev

\033[1;31m
 1: Website clone
 2: Sms bomber
 3: Image To string
 4: Zip password crack
 5: Admin page finder
 6: DDoS attack 
 
 Created by abduaziz
 
 > \033[1;32m""")
